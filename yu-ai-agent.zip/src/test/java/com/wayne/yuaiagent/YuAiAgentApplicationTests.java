package com.wayne.yuaiagent;

import com.wayne.yuaiagent.app.LoveApp;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.UUID;

@SpringBootTest

class YuAiAgentApplicationTests {
	@Resource
	private LoveApp loveApp;
	@Test
	void contextLoads() {
	}
	@Test
	void doChatWithRag() {
		String chatId = UUID.randomUUID().toString();
		String message = "我寂寞了，怎么办？";
		String answer =  loveApp.doChatWithRag(message, chatId);
		Assertions.assertNotNull(answer);
	}
	@Test
	void doChatWithTools() {
		// 测试联网搜索问题的答案
		testMessage("周末想带女朋友去上海约会，推荐几个适合情侣的小众打卡地？");

		// 测试网页抓取：恋爱案例分析
		testMessage("最近和对象吵架了，看看编程导航网站（codefather.cn）的其他情侣是怎么解决矛盾的？");

		// 测试资源下载：图片下载
		testMessage("直接下载一张适合做手机壁纸的星空情侣图片为文件");

		// 测试终端操作：执行代码
		testMessage("执行 Python3 脚本来生成数据分析报告");

		// 测试文件操作：保存用户档案
		testMessage("保存我的恋爱档案为文件");

		// 测试 PDF 生成
		testMessage("生成一份‘七夕约会计划’PDF，包含餐厅预订、活动流程和礼物清单");
	}

	private void testMessage(String message) {
		String chatId = UUID.randomUUID().toString();
		String answer = loveApp.doChatWithTools(message, chatId);
		Assertions.assertNotNull(answer);
	}
	@Test
	void doChatWithMcp() {
		String chatId = UUID.randomUUID().toString();
		// 测试图片搜索 MCP
		String message = "帮我搜索一些哄另一半开心的图	片";
		String answer =  loveApp.doChatWithMcp(message,chatId);
		Assertions.assertNotNull(answer);
	}

}
